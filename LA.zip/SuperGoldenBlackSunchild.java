package LA;

import robocode.*;
import robocode.util.Utils;
import LA.PatternMatch;
import LA.Enemy;

//import java.awt.Color;
/**
 * Newton
 * 
 * Imagina força na arena que o repelem ou atraem de certos "pontos de gravidade". Usa isto para evitar robots
 * inimigos, perseguir inimigos mais fracos e afastar-se de zonas menos favoráveis da arena.
 */


public class SuperGoldenBlackSunchild extends AdvancedRobot {
    static final double GUN_FACTOR = 50;
  static StringBuffer history = new StringBuffer("00000000000000000000000000000");
    static final double FIREPOWER = 2.5D;
  static final double BULLETVEL = 12.5D;
  
    static double xForce = 0;
    static double yForce = 0;
 
    static String lastTarget;
    static double lastDistance;

    //gravPoint gravField[10];
    static PatternMatch pGun;

    //_______________

    public void run() {
		pGun = new PatternMatch();
		setAdjustGunForRobotTurn(true);
		lastDistance = Double.POSITIVE_INFINITY;
		turnRadarRight(Double.POSITIVE_INFINITY);
    }
	
    public void onScannedRobot(ScannedRobotEvent e) {
		double heading = getHeadingRadians();
		double	absoluteBearing = e.getBearingRadians() + heading;	
		double  distance = e.getDistance();
		xForce *=.9;
		yForce *=.9;
	        int factor = 1;
		//Varia entre zero e um, e permite prioritizar deslocar o robot na direção de robos com menos energia e afastá-lo dos com mais energia
		//double attractionForce = 3 + Math.sin(2*Math.PI * (100/e.getEnergy()));
		double attractionForce = 1;
	        xForce -= (Math.sin(absoluteBearing)*attractionForce) / Math.pow(distance,1);
		yForce -= (Math.cos(absoluteBearing)*attractionForce) / Math.pow(distance,1);
			
	        //Tratamos a força das paredes como instântanea para não a somarmos em todos os eventos, evitamos assim o robot colar às paredes
		//Usamos um expoente maior para a força das paredes para nos manter mais afastados do centro do campo
		double wallRepulsion = 1;
	        double xWallForce = wallRepulsion/Math.pow(getX(),factor) - wallRepulsion/(Math.pow(getBattleFieldWidth() - getX(),factor));
		double yWallForce = wallRepulsion/Math.pow(getY(),factor) - wallRepulsion/(Math.pow(getBattleFieldHeight() - getY(),factor));
			
	        //Tiramos o novo ângulo absoluto pelo arctan das componentes da força resultante. Subtraímos o angulo actual para obter o ângulo que o
		//robot tem de completar
		double newAngle = Math.atan2(xWallForce + xForce, yWallForce + yForce) - getHeadingRadians();
	       
		newAngle = Utils.normalRelativeAngle(newAngle); //Normalizar o angulo
	
		setTurnRightRadians(newAngle);
		  
		setAhead(Double.POSITIVE_INFINITY);
		
		//Quanto mais apertada a curva, menor deve ser a velocidade para não demorarmos tanto tempo a virar
		setMaxVelocity( 420 / getTurnRemaining());
		
	    double dist = e.getDistance();
  	  	double absB = e.getBearingRadians() + getHeadingRadians();
		
		Enemy en = new Enemy();
		
		en.dist = e.getDistance();
		en.heading = e.getHeadingRadians();
		en.velocity = e.getVelocity();
		
		pGun.updateHistory(en, absB);
		double predictedBearing = pGun.getAngle(en,  absB, getHeading());

        setTurnGunRightRadians( Utils.normalRelativeAngle( predictedBearing - getGunHeadingRadians() ) );
        setFire(2.5D);
        
        setTurnRadarLeft(getRadarTurnRemaining());
	
    }

	

    public class vector {
        public double xComponent, yComponent;
	vector(double a, double b) {
	    xComponent = a;
	    yComponent = b;
	}
    }
	
    public class gravPoint {
        public double x,y;
	static final int EXPONENT = 1;
	//Force this point exerts over the robot. Negative for repulsion, positive for attraction
	private double force;
	gravPoint(double A, double B, double F) {
	    x = A;
	    y = B;
	    force = F;
	}
	//Force that this point exerts on a given point in the map
	public vector forceExerted(double A, double B) {
	    double distance = Math.sqrt((x*x - A*A)+(y*y - B*B));
	    double angle = Math.atan2(Math.abs(x - A), Math.abs(y - B));
	    double xComponent, yComponent;
	    xComponent = (Math.cos(angle)*force) / Math.pow(distance, EXPONENT);
	    yComponent = (Math.sin(angle)*force) / Math.pow(distance, EXPONENT);
	    vector v = new vector(xComponent, yComponent);
	    return v;
	}
    }
}
