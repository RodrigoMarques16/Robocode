package LA;

public class Enemy {
	public double dist;
	public double bearing;
	public double heading;
	public double velocity;
}
